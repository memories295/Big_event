<template>
    <div class="importFile">
       <div class=""></div>
    </div>
</template>

<script>

export default {
  name: 'importFile',
  data() {
    return {
      
    }
  },
  methods: {
  },
  mounted() {
    
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>

</style>
