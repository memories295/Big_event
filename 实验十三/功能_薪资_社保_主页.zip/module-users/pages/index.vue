<template>
  <div class="usersContainer">
    <div class="usersTop">
      <img src="./../../assets/img.jpeg" alt="">
      <div class="usersTopInfo">
        <p>早安，{{ myInfo.username }}，祝你开心每一天！</p>
        <p>{{ myInfo.post }} | {{ myInfo.departmentName }} </p>
      </div>
    </div>
    <div class="usersTop">
      <el-descriptions class="margin-top" title="个人信息" :column="3" :size="size" border>
        <template slot="extra">
          <el-button type="primary" size="small">submit</el-button>
        </template>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-user"></i>
            姓名
          </template>
          {{ myInfo.username }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            手机号
          </template>
          {{ myInfo.mobile }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-location-outline"></i>
            工号
          </template>
          111
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-tickets"></i>
            备注
          </template>
          山东大学
          <el-tag size="small">学校</el-tag>
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-office-building"></i>
            联系地址
          </template>
          山东省青岛市
        </el-descriptions-item>
      </el-descriptions>
    </div>

    <div class="usersTop">
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column prop="time" label="月份" width="180">
        </el-table-column>
        <el-table-column prop="salary" label="总薪资" width="180">
        </el-table-column>
        <el-table-column prop="basic" label="底薪">
        </el-table-column>
        <el-table-column prop="performance" label="提成">
        </el-table-column>
        <el-table-column prop="atte" label="出勤表现">
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import { detail } from '@/api/base/users'
import { list } from '@/api/hrm/noticesApi'
import Apply from './../components/Apply'
import OverTimeWork from './../components/OverTimeWork'
import LeaveRelevant from '../components/LeaveRelevant'
import DateIndex from '../components/DateIndex'
import { log } from 'util';
import getters from '@/store/getters'

export default {
  name: 'users-table-index',
  components: { Apply, OverTimeWork, LeaveRelevant, DateIndex },
  data() {
    return {
      dialogVisible: false,
      title: '离职',
      lab: '',
      userId: '',
      myInfo: {
      },
      noticesList: [
      ],
      tableData: [{
        time: '2024-3',
        salary: 9000,
        basic: 5000,
        performance: 4000,
        atte: 0
      }, {
        time: '2024-4',
        salary: 9500,
        basic: 5000,
        performance: 4000,
        atte: 500,
      }, {
        time: '2024-5',
        salary: 10000,
        basic: 5000,
        performance: 4500,
        atte: 500,
      }, {
        time: '2024-6',
        salary: 12000,
        salary: 10000,
        basic: 6000,
        performance: 6500,
        atte: 500,
      }]
    }
  },
  methods: {
    init() {
      this.userInfo()
      //this.getNotices()
    },
    noticeClick(item) {
      this.$bus.emit("noticeDetail", item)
      this.$bus.off()
    },
    async userInfo() {
      this.userId = getters.userId;
      let id = this.userId;
      const { data: userInfoRes } = await detail({ id })
      if (userInfoRes.success == true) {
        this.myInfo = userInfoRes.data
      }
    },
    async getNotices() {
      let dataMonth = this.dataMonth
      const { data: noticesRes } = await list({ status: 1 })
      if (noticesRes.success == true) {
        let arr = noticesRes.data.rows
        if (arr.length > 3) {
          this.noticesList = arr.slice(0, 3)
        } else {
          this.noticesList = arr
        }
      }
    },
    closeDialog() {
      this.lab = ''
      this.dialogVisible = false
    }
  },
  mounted() {
    this.init()
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "./../../styles/variables";

.usersContainer {
  padding: 25px 0;

  .usersTop {
    background: #fff;
    display: flex;
    padding: 20px;

    img {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      border: solid 1px #ccc;
      margin-right: 20px;
    }

    div {
      flex: 1;

      p {
        margin: 17px 0;
      }

      p:first-child {
        position: relative;
        font-weight: bold;
        top: 0px;
        font-size: 22px;
        line-height: 15px;
      }
    }
  }

  .usersContent {
    margin: 25px;

    .contBox {
      display: flex;

      .workCalendar {
        background: #fff;
        margin-right: 15px;
        border-radius: 5px 5px 0px 0px;
        flex: 2;

        .title {
          padding: 15px;
          border-bottom: solid 1px #ccc;
          font-size: 16px;
          font-weight: bold;
        }

        .contentItem {
          min-height: 350px;
        }
      }

      .shortcutEntrance {
        background: #fff;
        border-radius: 5px 5px 0px 0px;
        flex: 1;

        .title {
          padding: 15px;
          border-bottom: solid 1px #ccc;
          font-size: 16px;
          font-weight: bold;
        }

        .contentItem {
          padding: 15px;

          span {
            display: inline-block;
            border-radius: 3px;
            background: $green;
            color: #fff;
            padding: 8px 16px;
            margin-right: 10px;
          }
        }
      }
    }

    .advContent {
      margin: 15px 0;
      background: #fff;
      border-radius: 5px 5px 0px 0px;

      .title {
        font-size: 16px;
        padding: 20px;
        font-weight: bold;
        border-bottom: solid 1px #ccc;
      }

      .contentItem {
        padding: 0 30px;
        min-height: 350px;

        .item {
          display: flex;
          border-bottom: solid 1px #ccc;

          img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-right: 10px;
          }

          p {
            margin: 15px 0;

            span {
              color: $blue;
              font-weight: 500;
            }
          }
        }
      }
    }
  }
}
</style>
