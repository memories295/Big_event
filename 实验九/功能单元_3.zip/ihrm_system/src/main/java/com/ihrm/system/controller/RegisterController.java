package com.ihrm.system.controller;

import com.ihrm.domain.system.City;
import org.springframework.web.bind.annotation.*;
import com.ihrm.common.entity.Result;
import com.ihrm.common.entity.ResultCode;

@CrossOrigin
@RestController
@RequestMapping(value = "/frame")
public class RegisterController {
    @PostMapping(value = "/register/step1")
    public Result Register(@RequestBody(required = false) Object ignored){
        return new Result(ResultCode.SUCCESS);
    }
}
