// import Layout from '@/module-dashboard/pages/layout'
// const _import = require('@/router/import_' + process.env.NODE_ENV)
// export default [{
//   // root: true,
//   path: '/reg',
//   component: _import('dashboard/pages/reg'),
//   name: 'reg'
//   // hidden: true
// }]
